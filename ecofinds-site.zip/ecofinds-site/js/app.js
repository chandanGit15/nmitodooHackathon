// Common UI helpers shared by pages
function qs(sel, root=document){ return root.querySelector(sel); }
function qsa(sel, root=document){ return Array.from(root.querySelectorAll(sel)); }

function ensureAuth(redirectIfMissing=true){
  const u = currentUser();
  if(!u && redirectIfMissing){ window.location.href = 'index.html'; }
  return u;
}

function renderNav(){
  const nav = qs('#nav-links'); if(!nav) return;
  const u = currentUser();
  const count = u ? getCartProductIds().length : 0;
  nav.innerHTML = `
    <a class="btn" href="feed.html">Feed</a>
    <a class="btn" href="my-listings.html">My Listings</a>
    <a class="btn" href="cart.html">Cart${count? ' ('+count+')':''}</a>
    <a class="btn" href="orders.html">Orders</a>
    <a class="btn" href="profile.html">Profile</a>
    ${u ? '<button id="logoutBtn" class="btn">Logout</button>' : ''}
  `;
  const lb = qs('#logoutBtn');
  if(lb){ lb.addEventListener('click', () => { logout(); window.location.href='index.html'; }); }
}

function renderHeader(){
  const h = qs('#app-header');
  if(!h) return;
  h.innerHTML = `
    <div class="nav">
      <div class="brand"><div class="brand-logo">🌿</div>EcoFinds</div>
      <div id="nav-links" class="nav-links"></div>
    </div>
  `;
  renderNav();
}

document.addEventListener('DOMContentLoaded', () => {
  renderHeader();
  const page = document.body.dataset.page;

  if(page === 'auth'){ initAuth(); }
  if(page === 'feed'){ initFeed(); }
  if(page === 'add'){ initAdd(); }
  if(page === 'my'){ initMyListings(); }
  if(page === 'edit'){ initEdit(); }
  if(page === 'product'){ initProduct(); }
  if(page === 'cart'){ initCart(); }
  if(page === 'orders'){ initOrders(); }
  if(page === 'profile'){ initProfile(); }
});

// Page: Auth
function initAuth(){
  // if logged in, go to feed
  if(currentUser()){ window.location.href='feed.html'; return; }
  const formLogin = qs('#login-form');
  const formSignup = qs('#signup-form');
  const toggle = qs('#toggle-auth');
  const cardLogin = qs('#card-login');
  const cardSignup = qs('#card-signup');
  toggle.addEventListener('click', () => {
    cardLogin.classList.toggle('hidden');
    cardSignup.classList.toggle('hidden');
  });
  formLogin.addEventListener('submit', (e) => {
    e.preventDefault();
    try {
      login({ email: qs('#login-email').value, password: qs('#login-password').value });
      window.location.href='feed.html';
    } catch(err){ qs('#login-error').textContent = err.message; }
  });
  formSignup.addEventListener('submit', (e) => {
    e.preventDefault();
    try {
      signUp({ email: qs('#su-email').value, password: qs('#su-password').value, username: qs('#su-username').value });
      window.location.href='feed.html';
    } catch(err){ qs('#signup-error').textContent = err.message; }
  });
}

// Page: Feed
function initFeed(){
  ensureAuth();
  const products = getProducts().sort((a,b)=>b.createdAt-a.createdAt);
  const grid = qs('#feed-grid');
  const search = qs('#search');
  const cat = qs('#category');
  CATEGORIES.forEach(c => { const o=document.createElement('option'); o.value=c; o.textContent=c; cat.appendChild(o); });
  cat.value = 'All';

  function render(){
    const q = (search.value||'').toLowerCase();
    const selected = cat.value;
    const list = products.filter(p => (selected==='All'||p.category===selected) && (!q || p.title.toLowerCase().includes(q)));
    grid.innerHTML = list.map(p => `
      <div class="card">
        <img src="${p.image||DEFAULT_IMG}" alt="">
        <div class="content">
          <div class="row"><div class="right badge">${p.category}</div></div>
          <div style="font-weight:600; margin-bottom:6px;">${p.title}</div>
          <div class="price">₹ ${Number(p.price).toLocaleString()}</div>
          <div class="row" style="margin-top:10px;">
            <a class="btn primary" href="product.html?id=${p.id}">View</a>
          </div>
        </div>
      </div>
    `).join('');
  }
  render();
  search.addEventListener('input', render);
  cat.addEventListener('change', render);
  qs('#add-product').addEventListener('click', ()=> window.location.href='add.html');
}

// Page: Add
function initAdd(){
  ensureAuth();
  const form = qs('#product-form');
  const cat = qs('#p-category');
  CATEGORIES.filter(c=>c!=='All').forEach(c => { const o=document.createElement('option'); o.value=c; o.textContent=c; cat.appendChild(o); });
  form.addEventListener('submit', (e)=>{
    e.preventDefault();
    try {
      addProduct({ title: qs('#p-title').value, description: qs('#p-desc').value, category: qs('#p-category').value, price: Number(qs('#p-price').value||0), image: qs('#p-image').value || DEFAULT_IMG });
      window.location.href='my-listings.html';
    } catch(err){ alert(err.message); }
  });
}

// Page: My Listings
function initMyListings(){
  ensureAuth();
  const grid = qs('#my-grid');
  function render(){
    const list = listMyProducts().sort((a,b)=>b.createdAt-a.createdAt);
    grid.innerHTML = list.map(p => `
      <div class="card">
        <img src="${p.image||DEFAULT_IMG}" alt="">
        <div class="content">
          <div class="row"><div style="font-weight:600">${p.title}</div><div class="right price">₹ ${Number(p.price).toLocaleString()}</div></div>
          <div class="helper">${p.category}</div>
          <div class="row" style="margin-top:10px;">
            <a class="btn primary" href="edit.html?id=${p.id}">Edit</a>
            <button class="btn" data-del="${p.id}">Delete</button>
            <a class="btn" href="product.html?id=${p.id}">Open</a>
          </div>
        </div>
      </div>
    `).join('');
    qsa('[data-del]').forEach(b => b.addEventListener('click', ()=>{ if(confirm('Delete this product?')){ deleteProduct(b.dataset.del); render(); }}));
  }
  render();
  qs('#add-product').addEventListener('click', ()=> window.location.href='add.html');
}

// Page: Edit
function initEdit(){
  ensureAuth();
  const params = new URLSearchParams(location.search);
  const id = params.get('id'); const prod = getProductById(id);
  if(!prod){ alert('Product not found'); location.href='my-listings.html'; return; }
  const form = qs('#product-form');
  const cat = qs('#p-category');
  CATEGORIES.filter(c=>c!=='All').forEach(c => { const o=document.createElement('option'); o.value=c; o.textContent=c; cat.appendChild(o); });
  qs('#p-title').value = prod.title;
  qs('#p-desc').value = prod.description;
  qs('#p-category').value = prod.category;
  qs('#p-price').value = prod.price;
  qs('#p-image').value = prod.image || '';

  form.addEventListener('submit', (e)=>{
    e.preventDefault();
    try {
      updateProduct(id, { title: qs('#p-title').value, description: qs('#p-desc').value, category: qs('#p-category').value, price: Number(qs('#p-price').value||0), image: qs('#p-image').value || DEFAULT_IMG });
      window.location.href='my-listings.html';
    } catch(err){ alert(err.message); }
  });
}

// Page: Product Detail
function initProduct(){
  ensureAuth();
  const params = new URLSearchParams(location.search);
  const id = params.get('id'); const p = getProductById(id);
  if(!p){ alert('Product not found'); location.href='feed.html'; return; }
  qs('#pd-img').src = p.image || DEFAULT_IMG;
  qs('#pd-title').textContent = p.title;
  qs('#pd-price').textContent = '₹ ' + Number(p.price).toLocaleString();
  qs('#pd-cat').textContent = p.category;
  qs('#pd-desc').textContent = p.description;
  qs('#add-cart').addEventListener('click', ()=>{ addToCart(p.id); renderNav(); alert('Added to cart'); });
}

// Page: Cart
function initCart(){
  ensureAuth();
  const listEl = qs('#cart-list');
  function render(){
    const list = getCartProducts();
    if(list.length === 0){ listEl.innerHTML = '<div class="kicker">Your cart is empty.</div>'; return; }
    listEl.innerHTML = list.map(p => `
      <div class="card">
        <div class="row" style="align-items:center; padding: 10px;">
          <img src="${p.image||DEFAULT_IMG}" style="width:100px; height:80px; object-fit:cover; border-radius:10px; margin-right:10px;" />
          <div style="flex:1;">
            <div style="font-weight:600">${p.title}</div>
            <div class="helper">${p.category}</div>
          </div>
          <div class="price" style="margin-right:10px;">₹ ${Number(p.price).toLocaleString()}</div>
          <button class="btn" data-rm="${p.id}">Remove</button>
        </div>
      </div>
    `).join('');
    qsa('[data-rm]').forEach(b => b.addEventListener('click', ()=>{ removeFromCart(b.dataset.rm); render(); renderNav(); }));
  }
  render();
  qs('#checkout').addEventListener('click', ()=>{
    const items = getCartProducts();
    if(items.length === 0){ alert('Cart is empty'); return; }
    checkout(); render(); renderNav(); alert('Order placed!'); 
    window.location.href='orders.html';
  });
}

// Page: Orders
function initOrders(){
  ensureAuth();
  const listEl = qs('#orders-list');
  const u = currentUser();
  const orders = (getOrders()[u.id] || []).sort((a,b)=>b.ts-a.ts);
  if(orders.length === 0){ listEl.innerHTML = '<div class="kicker">No previous purchases yet.</div>'; return; }
  listEl.innerHTML = orders.map(o => {
    const p = o.product;
    const when = new Date(o.ts).toLocaleString();
    return `
      <div class="card">
        <div class="content">
          <div class="row"><div class="badge">Order #${o.orderId}</div><div class="right helper">${when}</div></div>
          <div class="row" style="margin-top:8px; align-items:center;">
            <img src="${p.image||DEFAULT_IMG}" style="width:120px; height:90px; object-fit:cover; border-radius:10px; margin-right:10px;" />
            <div style="flex:1;">
              <div style="font-weight:600">${p.title}</div>

              <div class="helper">${p.category}</div>
            </div>
            <div class="price">₹ ${Number(p.price).toLocaleString()}</div>
          </div>

        </div>
      </div>
    `;
  }).join('');
}

// Page: Profile
function initProfile(){
  const u = ensureAuth();
  qs('#pf-username').value = u.username || '';
  qs('#pf-email').value = u.email || '';
  qs('#save-profile').addEventListener('click', ()=>{
    updateProfile({ username: qs('#pf-username').value, email: qs('#pf-email').value });
    alert('Profile updated');
  });
}