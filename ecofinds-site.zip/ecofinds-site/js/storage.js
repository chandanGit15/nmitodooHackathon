// LocalStorage helpers and data layer
const LS = {
  get(key, fallback) {
    try { const v = localStorage.getItem(key); return v ? JSON.parse(v) : fallback; } catch(e){ return fallback; }
  },
  set(key, val) { localStorage.setItem(key, JSON.stringify(val)); },
  uid(prefix='id'){ return `${prefix}_${Date.now()}_${Math.floor(Math.random()*1e6)}`; }
};

const DB_KEYS = {
  users: 'ecf_users',
  products: 'ecf_products',
  carts: 'ecf_carts',
  orders: 'ecf_orders',
  session: 'ecf_session'
};

const CATEGORIES = ['All','Electronics','Fashion','Home','Books','Sports','Toys','Other'];
const DEFAULT_IMG = 'https://images.unsplash.com/photo-1516906571665-49c8b2f0b2aa?q=80&w=800&auto=format&fit=crop';

function getUsers(){ return LS.get(DB_KEYS.users, []); }
function setUsers(v){ LS.set(DB_KEYS.users, v); }
function getProducts(){ return LS.get(DB_KEYS.products, []); }
function setProducts(v){ LS.set(DB_KEYS.products, v); }
function getCarts(){ return LS.get(DB_KEYS.carts, {}); }
function setCarts(v){ LS.set(DB_KEYS.carts, v); }
function getOrders(){ return LS.get(DB_KEYS.orders, {}); }
function setOrders(v){ LS.set(DB_KEYS.orders, v); }
function getSession(){ return LS.get(DB_KEYS.session, null); }
function setSession(v){ LS.set(DB_KEYS.session, v); }

function currentUser(){
  const s = getSession(); if(!s) return null;
  return getUsers().find(u => u.id === s.userId) || null;
}

function signUp({email, password, username}){
  let users = getUsers();
  if(users.some(u => u.email === email)) throw new Error('Email already in use');
  const user = { id: LS.uid('user'), email, password, username, avatar: '' };
  users.push(user); setUsers(users); setSession({ userId: user.id });
  return user;
}

function login({email, password}){
  const user = getUsers().find(u => u.email === email && u.password === password);
  if(!user) throw new Error('Invalid credentials');
  setSession({ userId: user.id }); return user;
}

function logout(){ setSession(null); }

function updateProfile(partial){
  const u = currentUser(); if(!u) throw new Error('Not authenticated');
  let users = getUsers();
  users = users.map(x => x.id === u.id ? {...x, ...partial} : x);
  setUsers(users);
}

function addProduct({title, description, category, price, image}){
  const u = currentUser(); if(!u) throw new Error('Not authenticated');
  const p = { id: LS.uid('prod'), ownerId: u.id, title, description, category, price: Number(price||0), image: image || DEFAULT_IMG, createdAt: Date.now() };
  const products = getProducts(); products.push(p); setProducts(products); return p;
}

function updateProduct(id, data){
  const u = currentUser(); if(!u) throw new Error('Not authenticated');
  let prods = getProducts();
  const p = prods.find(x => x.id === id);
  if(!p) throw new Error('Product not found');
  if(p.ownerId !== u.id) throw new Error('Not your product');
  prods = prods.map(x => x.id === id ? {...x, ...data} : x);
  setProducts(prods);
}

function deleteProduct(id){
  const u = currentUser(); if(!u) throw new Error('Not authenticated');
  let prods = getProducts();
  const p = prods.find(x => x.id === id);
  if(!p) return;
  if(p.ownerId !== u.id) throw new Error('Not your product');
  prods = prods.filter(x => x.id !== id);
  setProducts(prods);
}

function getProductById(id){
  return getProducts().find(p => p.id === id) || null;
}

function listMyProducts(){
  const u = currentUser(); if(!u) throw new Error('Not authenticated');
  return getProducts().filter(p => p.ownerId === u.id);
}

function addToCart(productId){
  const u = currentUser(); if(!u) throw new Error('Not authenticated');
  const c = getCarts();
  const arr = c[u.id] || [];
  if(!arr.includes(productId)) arr.push(productId);
  c[u.id] = arr; setCarts(c);
}

function removeFromCart(productId){
  const u = currentUser(); if(!u) throw new Error('Not authenticated');
  const c = getCarts();
  c[u.id] = (c[u.id]||[]).filter(id => id !== productId);
  setCarts(c);
}

function getCartProductIds(){
  const u = currentUser(); if(!u) throw new Error('Not authenticated');
  const c = getCarts(); return c[u.id] || [];
}

function getCartProducts(){
  const ids = getCartProductIds();
  return getProducts().filter(p => ids.includes(p.id));
}

function checkout(){
  const u = currentUser(); if(!u) throw new Error('Not authenticated');
  const cartProds = getCartProducts();
  if(cartProds.length === 0) return [];
  const orders = getOrders();
  const my = orders[u.id] || [];
  cartProds.forEach(p => {
    my.push({ orderId: LS.uid('ord'), ts: Date.now(), product: {...p} });
  });
  orders[u.id] = my; setOrders(orders);
  // clear cart
  const c = getCarts(); c[u.id] = []; setCarts(c);
  return my.slice(-cartProds.length);
}

// Seed demo data if empty
(function seed(){ 
  if(getProducts().length === 0){
    const demoOwner = signUp({email:'demo@ecofinds.app', password:'demo123', username:'demo'});
    updateProfile({ username: 'demo' });
    const items = [
      {title:'Kindle Paperwhite (2019)', category:'Electronics', price:5999, description:'Gently used, great battery.', image: DEFAULT_IMG},
      {title:'IKEA Wooden Chair', category:'Home', price:1499, description:'Solid wood, minor scratches.', image: DEFAULT_IMG},
      {title:'Nike Running Shoes', category:'Sports', price:1999, description:'Size 9, barely used.', image: DEFAULT_IMG},
      {title:'Data Structures Book', category:'Books', price:399, description:'Clean pages, no highlights.', image: DEFAULT_IMG},
    ];
    items.forEach(addProduct);
    // logout demo so first-time user starts at auth
    logout();
  }
})();