To test with a local .glb file, place it in this 'models' folder and set the model URL in the Add Product form to 'models/your-model.glb'.

Note: model-viewer requires the file to be served over HTTP (open via a local server) to load local models in some browsers.