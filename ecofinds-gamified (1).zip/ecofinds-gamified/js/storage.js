// LocalStorage helpers and data layer (gamified)
const LS = {
  get(key, fallback) {
    try { const v = localStorage.getItem(key); return v ? JSON.parse(v) : fallback; } catch(e){ return fallback; }
  },
  set(key, val) { localStorage.setItem(key, JSON.stringify(val)); },
  uid(prefix='id'){ return `${prefix}_${Date.now()}_${Math.floor(Math.random()*1e6)}`; }
};

const DB_KEYS = {
  users: 'ecf_users',
  products: 'ecf_products',
  carts: 'ecf_carts',
  orders: 'ecf_orders',
  session: 'ecf_session',
  meta: 'ecf_meta' // store points, badges, streaks
};

const CATEGORIES = ['All','Electronics','Fashion','Home','Books','Sports','Toys','Other'];
const DEFAULT_IMG = 'https://images.unsplash.com/photo-1516906571665-49c8b2f0b2aa?q=80&w=800&auto=format&fit=crop';
const SAMPLE_MODEL = 'https://modelviewer.dev/shared-assets/models/Chair.glb'; // online sample model

function getUsers(){ return LS.get(DB_KEYS.users, []); }
function setUsers(v){ LS.set(DB_KEYS.users, v); }
function getProducts(){ return LS.get(DB_KEYS.products, []); }
function setProducts(v){ LS.set(DB_KEYS.products, v); }
function getCarts(){ return LS.get(DB_KEYS.carts, {}); }
function setCarts(v){ LS.set(DB_KEYS.carts, v); }
function getOrders(){ return LS.get(DB_KEYS.orders, {}); }
function setOrders(v){ LS.set(DB_KEYS.orders, v); }
function getSession(){ return LS.get(DB_KEYS.session, null); }
function setSession(v){ LS.set(DB_KEYS.session, v); }
function getMeta(){ return LS.get(DB_KEYS.meta, {}); }
function setMeta(v){ LS.set(DB_KEYS.meta, v); }

function ensureUserMeta(userId){
  const meta = getMeta();
  if(!meta[userId]) meta[userId] = { points:0, badges:[], streak:0, lastLogin:0 };
  setMeta(meta);
  return meta[userId];
}

function currentUser(){
  const s = getSession(); if(!s) return null;
  return getUsers().find(u => u.id === s.userId) || null;
}

function signUp({email, password, username}){
  let users = getUsers();
  if(users.some(u => u.email === email)) throw new Error('Email already in use');
  const user = { id: LS.uid('user'), email, password, username, avatar: '' };
  users.push(user); setUsers(users); setSession({ userId: user.id });
  ensureUserMeta(user.id);
  return user;
}

function login({email, password}){
  const user = getUsers().find(u => u.email === email && u.password === password);
  if(!user) throw new Error('Invalid credentials');
  setSession({ userId: user.id });
  // streak handling
  const meta = getMeta();
  ensureUserMeta(user.id);
  const now = Date.now();
  const last = meta[user.id].lastLogin || 0;
  const oneDay = 24*60*60*1000;
  if(now - last < oneDay) {
    // same day login: keep streak
  } else if(now - last < 2*oneDay) {
    meta[user.id].streak = (meta[user.id].streak || 0) + 1;
  } else {
    meta[user.id].streak = 1;
  }
  meta[user.id].lastLogin = now;
  setMeta(meta);
  return user;
}

function logout(){ setSession(null); }

function updateProfile(partial){
  const u = currentUser(); if(!u) throw new Error('Not authenticated');
  let users = getUsers();
  users = users.map(x => x.id === u.id ? {...x, ...partial} : x);
  setUsers(users);
}

function addPoints(userId, n){
  const meta = getMeta();
  ensureUserMeta(userId);
  meta[userId].points = (meta[userId].points||0) + n;
  setMeta(meta);
}

function addBadge(userId, badge){
  const meta = getMeta();
  ensureUserMeta(userId);
  if(!meta[userId].badges.includes(badge)) meta[userId].badges.push(badge);
  setMeta(meta);
}

function getLeaderboard(){
  const users = getUsers();
  const meta = getMeta();
  const list = users.map(u => ({ id: u.id, username: u.username, points: (meta[u.id]||{}).points||0 }));
  return list.sort((a,b)=>b.points-a.points);
}

function addProduct({title, description, category, price, image, modelUrl}){
  const u = currentUser(); if(!u) throw new Error('Not authenticated');
  const p = { id: LS.uid('prod'), ownerId: u.id, title, description, category, price: Number(price||0), image: image || DEFAULT_IMG, modelUrl: modelUrl || '', createdAt: Date.now() };
  const products = getProducts(); products.push(p); setProducts(products);
  // gamification: +10 points for listing, first-listing badge
  addPoints(u.id, 10);
  const meta = getMeta();
  ensureUserMeta(u.id);
  if((getProducts().filter(x=>x.ownerId===u.id).length) === 1){
    addBadge(u.id, 'Eco Saver 🌱');
  }
  // badge for top seller at 10 listings
  const cnt = getProducts().filter(x=>x.ownerId===u.id).length;
  if(cnt >= 10) addBadge(u.id, 'Top Seller 🏆');
  return p;
}

function updateProduct(id, data){
  const u = currentUser(); if(!u) throw new Error('Not authenticated');
  let prods = getProducts();
  const p = prods.find(x => x.id === id);
  if(!p) throw new Error('Product not found');
  if(p.ownerId !== u.id) throw new Error('Not your product');
  prods = prods.map(x => x.id === id ? {...x, ...data} : x);
  setProducts(prods);
}

function deleteProduct(id){
  const u = currentUser(); if(!u) throw new Error('Not authenticated');
  let prods = getProducts();
  const p = prods.find(x => x.id === id);
  if(!p) return;
  if(p.ownerId !== u.id) throw new Error('Not your product');
  prods = prods.filter(x => x.id !== id);
  setProducts(prods);
}

function getProductById(id){
  return getProducts().find(p => p.id === id) || null;
}

function listMyProducts(){
  const u = currentUser(); if(!u) throw new Error('Not authenticated');
  return getProducts().filter(p => p.ownerId === u.id);
}

function addToCart(productId){
  const u = currentUser(); if(!u) throw new Error('Not authenticated');
  const c = getCarts();
  const arr = c[u.id] || [];
  if(!arr.includes(productId)) arr.push(productId);
  c[u.id] = arr; setCarts(c);
}

function removeFromCart(productId){
  const u = currentUser(); if(!u) throw new Error('Not authenticated');
  const c = getCarts();
  c[u.id] = (c[u.id]||[]).filter(id => id !== productId);
  setCarts(c);
}

function getCartProductIds(){
  const u = currentUser(); if(!u) throw new Error('Not authenticated');
  const c = getCarts(); return c[u.id] || [];
}

function getCartProducts(){
  const ids = getCartProductIds();
  return getProducts().filter(p => ids.includes(p.id));
}

function checkout(){
  const u = currentUser(); if(!u) throw new Error('Not authenticated');
  const cartProds = getCartProducts();
  if(cartProds.length === 0) return [];
  const orders = getOrders();
  const my = orders[u.id] || [];
  cartProds.forEach(p => {
    my.push({ orderId: LS.uid('ord'), ts: Date.now(), product: {...p} });
  });
  orders[u.id] = my; setOrders(orders);
  // clear cart
  const c = getCarts(); c[u.id] = []; setCarts(c);
  // gamification
  addPoints(u.id, 20);
  const meta = getMeta();
  ensureUserMeta(u.id);
  if((orders[u.id] || []).length >= 5) addBadge(u.id, 'Treasure Hunter 🔎');
  return my.slice(-cartProds.length);
}

// Seed demo data if empty
(function seed(){ 
  if(getProducts().length === 0){
    // create demo user if not exists
    const users = getUsers();
    let demo = users.find(u => u.email==='demo@ecofinds.app');
    if(!demo){
      demo = { id: LS.uid('user'), email:'demo@ecofinds.app', password:'demo123', username:'demo', avatar:'' };
      users.push(demo); setUsers(users);
      ensureUserMeta(demo.id);
      addPoints(demo.id, 50); // some starter points
    }
    setUsers(users);
    const items = [
      {title:'Kindle Paperwhite (2019)', category:'Electronics', price:5999, description:'Gently used, great battery.', image: DEFAULT_IMG, modelUrl: SAMPLE_MODEL},
      {title:'IKEA Wooden Chair', category:'Home', price:1499, description:'Solid wood, minor scratches.', image: DEFAULT_IMG, modelUrl: SAMPLE_MODEL},
      {title:'Nike Running Shoes', category:'Sports', price:1999, description:'Size 9, barely used.', image: DEFAULT_IMG, modelUrl: ''},
      {title:'Data Structures Book', category:'Books', price:399, description:'Clean pages, no highlights.', image: DEFAULT_IMG, modelUrl: ''},
    ];
    items.forEach(it => {
      const p = { id: LS.uid('prod'), ownerId: demo.id, title: it.title, description: it.description, category: it.category, price: it.price, image: it.image, modelUrl: it.modelUrl, createdAt: Date.now() };
      const prods = getProducts(); prods.push(p); setProducts(prods);
    });
    // logout demo so first-time user starts at auth
    logout();
  }
})();